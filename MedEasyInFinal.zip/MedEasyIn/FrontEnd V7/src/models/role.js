export const Role = {
  USER: 'CUSTOMER',
  ADMIN: 'ADMIN',
};
