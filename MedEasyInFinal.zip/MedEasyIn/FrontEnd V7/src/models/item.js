export default class CartItem {
    constructor(quantity,userId,productId) {
      this.productId = productId;
      this.userId = userId;
      this.quantity = quantity;
    // private Integer quantity;
	// private Double totalPrice;
	// private Long cartId;
	// private Long productId;
    }
  }
  