package com.app.entities;

public enum Status {
	PLACED,DELIVERED,IN_PROCESS,CANCELED

}
